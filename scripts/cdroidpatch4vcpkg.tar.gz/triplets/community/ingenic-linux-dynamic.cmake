#for ingenic x2600
set(VCPKG_TARGET_ARCHITECTURE mips)
set(VCPKG_CRT_LINKAGE dynamic)
set(VCPKG_LIBRARY_LINKAGE dynamic)
set(VCPKG_CROSSCOMPILING TRUE)
set(VCPKG_MESON_CROSS_FILE "${VCPKG_ROOT_DIR}/scripts/toolchains/ingenic_meson_cross.txt")

set(VCPKG_CMAKE_SYSTEM_NAME Linux)
set(VCPKG_MAKE_BUILD_TRIPLET "--host=mips-linux-gnu")
set(VCPKG_PLATFORM_TOOLSET "mips-linux-gnu")
set(CDROID_PORT "ingenic")
set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "${VCPKG_ROOT_DIR}/scripts/toolchains/ingenic-toolchain.cmake")

