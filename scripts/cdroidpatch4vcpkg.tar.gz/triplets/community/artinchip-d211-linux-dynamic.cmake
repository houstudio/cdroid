#for ingenic artinchip d211
set(VCPKG_TARGET_ARCHITECTURE riscv64)
set(VCPKG_CRT_LINKAGE dynamic)
set(VCPKG_LIBRARY_LINKAGE dynamic)
set(VCPKG_CROSSCOMPILING TRUE)
set(VCPKG_MESON_CROSS_FILE "${VCPKG_ROOT_DIR}/scripts/toolchains/artinchip_d211_meson_cross.txt")
SET(VCPKG_MESON_NATIVE_FILE "${VCPKG_ROOT_DIR}/scripts/toolchains/artinchip_d211_meson_native.txt")

set(VCPKG_CMAKE_SYSTEM_OPTIONS "-DCMAKE_POSITION_INDEPENDENT_CODE=ON")
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

set(VCPKG_CMAKE_SYSTEM_NAME Linux)
set(VCPKG_MAKE_BUILD_TRIPLET "--host=riscv64-unknown-linux-gnu")
set(VCPKG_PLATFORM_TOOLSET "riscv64-unknown-linux-gnu")
set(CDROID_PORT "d211")
set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "${VCPKG_ROOT_DIR}/scripts/toolchains/artinchip-d211-toolchain.cmake")

