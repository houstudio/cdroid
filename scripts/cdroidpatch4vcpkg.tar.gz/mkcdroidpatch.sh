rm vcpkgpatch4cdroid.tar.gz 
git status --porcelain | awk '{print $NF}' | grep -v -E "(\.gz$)" | xargs tar -czf vcpkgpatch4cdroid.tar.gz
