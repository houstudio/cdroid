#处理参数，规范化参数
ARGS=`getopt -a -o t:h:: --long triplet:,help:: -- "$@"`
#echo $ARGS
eval set -- "${ARGS}"
VCPKGROOT=""
#将规范化后的命令行参数分配至位置参数（$1,$2,...)
while :
do
   case $1 in
        -t|--triplet)
                TRIPLET=$2
                echo "triplet=$TRIPLET"
                shift
                ;;
        -h|--help)
                SHOWHELP=1
                echo "showhelp"
                shift
                ;;
        --)
                shift
                break
                ;;
        *)
                break
                ;;
   esac
   shift
done

if [ -n"$TRIPLET" ]; then
   ./vcpkg install zlib libunibreak libpng[apng] giflib libwebp libjpeg-turbo[jpeg8] libzip[core] gtest jsoncpp freetype[core,zlib,bzip2] cairo --triplet=$TRIPLET
   ./vcpkg install ghc-filesystem libqrencode fribidi curl[mbedtls] libhv --recurse --triplet=$TRIPLET
else
   echo $0" --triplet=triplet_name" 
fi

#skia without opengl/vulkan install params
#./vcpkg install skia[core,fontconfig,freetype,harfbuzz]
